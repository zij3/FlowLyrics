(() => {
  "use strict";

  const FRESH_TRACK_GUARD_MS = 5000;
  const METADATA_GAP_GRACE_MS = 2500;
  const NATIVE_PANE_HOLD_MS = 5000;
  const STALE_HANDOFF_TIME_SECONDS = 20;
  const SCAN_INTERVAL_MS = 1300;
  const {
    LyricsOverlay,
    lyricsService,
    offsetController,
    playerPage,
    playbackWatcher,
    trackReader,
    utils
  } = globalThis.YTML;

  const state = {
    activeIndex: -1,
    freshTrackGuardUntil: 0,
    hasSyncedLyrics: false,
    lines: [],
    loading: false,
    lyricsRequestId: 0,
    missingMetadataSince: 0,
    nativePaneHoldUntil: 0,
    offsetSeconds: offsetController.loadOffset(),
    placementQueued: false,
    rafId: 0,
    scanQueued: false,
    track: null,
    trackKey: ""
  };

  const overlay = new LyricsOverlay({
    formatOffset: offsetController.formatOffset,
    onOffsetChange: handleOffsetChange,
    onShown: () => syncToCurrentLyric(true)
  });
  overlay.setOffset(state.offsetSeconds);

  init();

  function init() {
    playerPage.observePlayerPage({
      onCloseRequested: () => overlay.hideImmediately(),
      onPlacementRequested: schedulePlacementUpdate,
      onScanRequested: scheduleScan
    });
    playbackWatcher.observePlayback({
      onPlaybackReady: scheduleScan,
      onTrackBoundary: handleTrackBoundary
    });

    scanTrack(true);
    setInterval(() => scanTrack(false), SCAN_INTERVAL_MS);
    state.rafId = requestAnimationFrame(syncLoop);
  }

  function scheduleScan() {
    if (state.scanQueued) {
      return;
    }

    state.scanQueued = true;
    requestAnimationFrame(() => {
      state.scanQueued = false;
      scanTrack(false);
      updatePlacement();
    });
  }

  function schedulePlacementUpdate() {
    if (state.placementQueued) {
      return;
    }

    state.placementQueued = true;
    requestAnimationFrame(() => {
      state.placementQueued = false;
      updatePlacement();
    });
  }

  function scanTrack(force) {
    const video = utils.getVideo();
    const track = trackReader.readTrack();
    updatePlacement();

    if (!force && video?.ended) {
      if (state.trackKey || state.hasSyncedLyrics || state.lines.length) {
        handleTrackBoundary();
      } else if (!isNativePaneHeld()) {
        resetTrack();
      }

      updatePlacement();
      return;
    }

    if (!track.title || !track.artist) {
      if (waitForTransientMetadata()) {
        updatePlacement();
        return;
      }

      resetTrack();
      updatePlacement();
      return;
    }

    state.missingMetadataSince = 0;
    const nextKey = utils.buildTrackKey(track);
    if (!force && nextKey === state.trackKey) {
      return;
    }

    state.track = track;
    state.trackKey = nextKey;
    state.freshTrackGuardUntil = performance.now() + FRESH_TRACK_GUARD_MS;
    state.loading = true;
    holdNativePane();
    clearLyrics();
    updatePlacement();
    loadLyricsForTrack(track, nextKey, ++state.lyricsRequestId);
  }

  async function loadLyricsForTrack(track, requestKey, requestId) {
    let shouldSync = false;
    state.loading = true;
    clearLyrics();
    updatePlacement();

    try {
      const lines = await lyricsService.loadSyncedLines(track, false);
      if (!isCurrentLyricsRequest(requestKey, requestId)) {
        return;
      }

      if (lines.length) {
        state.lines = lines;
        state.hasSyncedLyrics = true;
        state.nativePaneHoldUntil = 0;
        overlay.renderLines(lines);
        shouldSync = true;
      } else {
        state.nativePaneHoldUntil = 0;
      }
    } catch (_error) {
      if (isCurrentLyricsRequest(requestKey, requestId)) {
        state.nativePaneHoldUntil = 0;
        clearLyrics();
      }
    } finally {
      if (isCurrentLyricsRequest(requestKey, requestId)) {
        state.loading = false;
        updatePlacement();
        if (shouldSync) {
          syncToCurrentLyric(true);
        }
      }
    }
  }

  function handleTrackBoundary() {
    state.lyricsRequestId += 1;
    state.freshTrackGuardUntil = performance.now() + FRESH_TRACK_GUARD_MS;
    state.loading = false;
    state.track = null;
    state.trackKey = "";
    holdNativePane();
    clearLyrics();
    updatePlacement();
  }

  function waitForTransientMetadata() {
    const canWait = state.trackKey || state.hasSyncedLyrics || state.loading || isNativePaneHeld();
    if (!canWait) {
      state.missingMetadataSince = 0;
      return false;
    }

    const now = performance.now();
    if (!state.missingMetadataSince) {
      state.missingMetadataSince = now;
    }

    if (now - state.missingMetadataSince > METADATA_GAP_GRACE_MS) {
      state.missingMetadataSince = 0;
      return false;
    }

    holdNativePane(METADATA_GAP_GRACE_MS);
    return true;
  }

  function holdNativePane(duration = NATIVE_PANE_HOLD_MS) {
    state.nativePaneHoldUntil = Math.max(state.nativePaneHoldUntil, performance.now() + duration);
  }

  function isNativePaneHeld() {
    return performance.now() < state.nativePaneHoldUntil;
  }

  function isReplacingLyricsPane() {
    return state.loading || isNativePaneHeld() || (state.hasSyncedLyrics && state.lines.length);
  }

  function resetTrack() {
    state.track = null;
    state.trackKey = "";
    state.loading = false;
    state.nativePaneHoldUntil = 0;
    clearLyrics();
  }

  function isCurrentLyricsRequest(requestKey, requestId) {
    return requestKey === state.trackKey && requestId === state.lyricsRequestId;
  }

  function handleOffsetChange(action) {
    if (action === "reset") {
      state.offsetSeconds = offsetController.saveOffset(0);
    } else if (action === "increase-large") {
      state.offsetSeconds = offsetController.saveOffset(offsetController.adjustOffset(state.offsetSeconds, 1, offsetController.JUMP_SECONDS));
    } else if (action === "decrease-large") {
      state.offsetSeconds = offsetController.saveOffset(offsetController.adjustOffset(state.offsetSeconds, -1, offsetController.JUMP_SECONDS));
    } else if (action === "increase") {
      state.offsetSeconds = offsetController.saveOffset(offsetController.adjustOffset(state.offsetSeconds, 1));
    } else if (action === "decrease") {
      state.offsetSeconds = offsetController.saveOffset(offsetController.adjustOffset(state.offsetSeconds, -1));
    }

    overlay.setOffset(state.offsetSeconds);
    syncToCurrentLyric(true);
  }

  function clearLyrics() {
    state.activeIndex = -1;
    state.hasSyncedLyrics = false;
    state.lines = [];
    overlay.clearLines();
  }

  function syncLoop() {
    syncToCurrentLyric(false);
    state.rafId = requestAnimationFrame(syncLoop);
  }

  function syncToCurrentLyric(forceScroll) {
    const video = utils.getVideo();
    if (!video || video.ended || !state.lines.length) {
      return;
    }

    const nextIndex = findActiveIndex(readOffsetSyncTime(video), state.lines);
    if (forceScroll || nextIndex !== state.activeIndex) {
      state.activeIndex = nextIndex;
      overlay.updateActiveLine(nextIndex, forceScroll);
    }
  }

  function readOffsetSyncTime(video) {
    return Math.max(0, readSyncTime(video) - state.offsetSeconds);
  }

  function readSyncTime(video) {
    const playerBarTime = trackReader.readPlaybackTime();
    const hasPlayerBarTime = Number.isFinite(playerBarTime);
    const time = hasPlayerBarTime ? playerBarTime : video.currentTime || 0;

    if (
      !hasPlayerBarTime
      && performance.now() < state.freshTrackGuardUntil
      && time > STALE_HANDOFF_TIME_SECONDS
    ) {
      return 0;
    }

    if (time <= STALE_HANDOFF_TIME_SECONDS) {
      state.freshTrackGuardUntil = 0;
    }

    return time;
  }

  function findActiveIndex(time, lines) {
    let low = 0;
    let high = lines.length - 1;
    let answer = 0;

    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      if (lines[mid].time <= time) {
        answer = mid;
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }

    return answer;
  }

  function updatePlacement() {
    const playerPageElement = document.querySelector("ytmusic-player-page");
    const playerOpen = playerPage.isPlayerPageOpen(playerPageElement);
    const lyricsSelected = playerPage.isLyricsTabSelected();
    const hostRect = playerPage.getLyricsHostRect(playerPageElement);
    const visible = Boolean(playerOpen && lyricsSelected && hostRect && isReplacingLyricsPane());

    overlay.setLoading(state.loading);
    overlay.setOffsetControlsVisible(state.hasSyncedLyrics && state.lines.length);
    overlay.updatePlacement({
      hostRect,
      playerOpen,
      visible
    });
  }
})();
